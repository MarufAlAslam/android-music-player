package com.example.musicplayer;

import android.view.View;
import android.widget.TextView;

public class ViewHolder {
    TextView info;
    ViewHolder(TextView mInfo){
        this.info=mInfo;
    }
}
